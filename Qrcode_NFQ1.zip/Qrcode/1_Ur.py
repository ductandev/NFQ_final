
from datetime import datetime
import pickle
import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import cv2
import os

from time import sleep
import threading
from serial import Serial
import tensorflow
import detect_face

# from GUIVIDEO import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import  QWidget, QLabel, QApplication,QVBoxLayout
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import  QThread,  pyqtSignal, pyqtSlot, Qt
from PyQt5.QtWebEngineWidgets import QWebEngineSettings

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

# ----tensorflow version check
if tensorflow.__version__.startswith('1.'):
    import tensorflow as tf
else:
    import tensorflow.compat.v1 as tf
    tf.disable_v2_behavior()
print("Tensorflow version: ",tf.__version__)



from json import dumps, load, loads
font_cv = cv2.FONT_HERSHEY_SIMPLEX
unknownTemperature = []
unknownTime = []
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'JPG'} 



address_congty = "24 Nguyen Binh Khiem, Da Kao Ward, District 1, Ho Chi Minh City"
three_step_nfq = """
1. Please scan your body temperature.
2. Please sanitize your hands.
3. Please scan the below QR Code and show the
result to the Receptionist or Security."""


class Thread(QThread):
    changePixmap = pyqtSignal(QImage, name='video')
    changeName = pyqtSignal(str, name='name')
    changeMnv = pyqtSignal(str, name='mnv')
    changeTime = pyqtSignal(str, name='time')
    changePhoto = pyqtSignal(QImage, name='avatar')
    changePhoto2 = pyqtSignal(QImage, name='avatar2')
    changePhoto3 = pyqtSignal(QImage, name='avatar3')
    changeTemperature = pyqtSignal(str, name='temperature')



    def write_read(self, x):
        self.arduino.write(bytes(x, 'utf-8'))
        sleep(0.05)
        data = self.arduino.readline()
        return data

    def soud(self, staffName):

        os.system("mpg123 warning2.mp3")

    def soud2(self, staffName):
    
        os.system("mpg123 wash_hand_scan_qrcode.mp3")

    def soud3(self, names):
        os.system("mpg123 succss.mp3")



    def run(self):

        try:
            self.arduino =  Serial(port='/dev/ttyUSB0', baudrate=9600, timeout=.1)
        except Exception as e:
            print(e)

        self.temperature = 17
        self.threshold = 70
        self.color = (0,255,0)
        self.minsize = 550  # minimum size of face
        self.threshold = [0.6, 0.7, 0.7]  # three steps's threshold
        self.factor = 0.709  # scale factor
        with tf.Graph().as_default():
            config = tf.ConfigProto(log_device_placement=False,
                                    allow_soft_placement=False
                                    )
            config.gpu_options.per_process_gpu_memory_fraction = 0
            sess = tf.Session(config=config)
            with sess.as_default():
                self.pnet, self.rnet, self.onet = detect_face.create_mtcnn(sess, None)
        self.cap = cv2.VideoCapture(0) 
        
        self.cap.set(cv2.CAP_PROP_AUTOFOCUS, 1)
        self.cap.set(3, 1280) 
        self.cap.set(4, 720)

        self.start_time_temp = time.time()
        self.interrup_time = time.time() - 11
        self.demwaring = 0

        while (self.cap.isOpened()):     
            self.ret, self.frame = self.cap.read()
            if self.ret:
                self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
                try:
                    self.bounding_boxes, self.points = detect_face.detect_face(self.frame, self.minsize, self.pnet, self.rnet, self.onet, self.threshold, self.factor)
                    self.nrof_faces = self.bounding_boxes.shape[0]
                    # cv2.rectangle(self.frame, (320,180), (960,540), self.color, 2)
                    self.timeDetect = datetime.now().strftime("%H:%M:%S")
                



                    if self.nrof_faces > 0:
                        if  ((time.time() - self.interrup_time ) > 7):
                            self.interrup_time = time.time()
   
                            while True:
                                try:
                                    num = '?'
                                    value = self.write_read(num).decode("utf8","ignore")
                                    x_max = float(value)
                                    self.temperature =  round(0.1455*x_max + 32.108,2)  

                                    if (self.temperature > 37.5):
                                        if (self.temperature > 38.5):
                                            self.temperature= 38.5 

                                        t1_s = threading.Thread(target=self.soud, args=( time.time(), ))
                                        t1_s.start()
                                    if (self.temperature < 35.5):
                                        self.temperature= 35.5              
                                    break
                                except Exception as es:
                                    print("es---------------------------------------    {}".format(es))
                                    self.temperature = "None"
                                    try:
                                        self.arduino =  Serial(port='/dev/ttyUSB0', baudrate=9600, timeout=.1)
                                    except Exception as e:
                                        print(e)
                                    break



                            t2_s = threading.Thread(target=self.soud2, args=( time.time(), ))
                            t2_s.start()

                            img_save_1 = Image.open("recogniteImage/people_recognite_1.png")  # image extension *.png,*.jpg
                            img_save_1.save("recogniteImage/people_recognite_3.png")

                            cv2.imwrite('img.png', cv2.cvtColor(self.frame, cv2.COLOR_RGB2BGR))
                            self.changeTemperature.emit(str(self.temperature))
                            self.changeTime.emit(str(self.timeDetect))
                            img_save_4 = Image.open("img.png")
                            width, height = img_save_4.size
                            x = (width - height) // 2
                            img_cropped = img_save_4.crop((x, 0, x + height, height))
                            mask = Image.new('L', img_cropped.size)
                            mask_draw = ImageDraw.Draw(mask)
                            width, height = img_cropped.size
                            mask_draw.ellipse((10, 10, width-10, height-10), fill=255)
                            img_cropped.putalpha(mask)
                            img_save_4 = img_cropped.resize((128, 128), Image.ANTIALIAS)
                            img_save_4.save("recogniteImage/people_recognite_1.png")
                            photo = QImage('recogniteImage/people_recognite_1.png')
                            self.changePhoto.emit(photo)  
                    else:
                        cv2.putText(self.frame, "No face", (300, 300), cv2.FONT_HERSHEY_SIMPLEX, 5, (255, 0, 0), 5)

                except Exception as e:
                    print(e)
  
                self.frame = cv2.cvtColor(self.frame, cv2.COLOR_RGB2BGR) 
                cv2.putText(self.frame, str(datetime.now().strftime("%Y/%m/%d , %H:%M:%S")), (80,60), font_cv, 1, (0, 0, 255), 2, cv2.LINE_AA)
                rgbImage = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
                h, w, ch = rgbImage.shape
                bytesPerLine = ch * w
                convertToQtFormat = QImage(rgbImage.data, w, h, bytesPerLine, QImage.Format_RGB888)
                p = convertToQtFormat.scaled(640, 480, Qt.KeepAspectRatio)
                self.changePixmap.emit(p)
                if cv2.waitKey(1) & 0xFF == ord("q"): 
                    self.cap.release()
                    cv2.destroyAllWindows()
                    exit(0)


class Ui_MainWindow(object):
    def __init__(self):
        super().__init__()
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.address = QtWidgets.QLabel(self.centralwidget)
        self.three_step = QtWidgets.QLabel(self.centralwidget)
        self.temp = QtWidgets.QLabel(self.centralwidget)
        self.time_log = QtWidgets.QLabel(self.centralwidget)
        self.mnv = QtWidgets.QLabel(self.centralwidget)
        self.photo = QtWidgets.QLabel(self.centralwidget)
        self.photo_title = QtWidgets.QLabel(self.centralwidget)
        self.logo = QtWidgets.QLabel(self.centralwidget)
        self.titkul_hotline = QtWidgets.QLabel(self.centralwidget)
        self.video = QtWidgets.QLabel(self.centralwidget)
        self.qr_yte = QtWidgets.QLabel(self.centralwidget)


        try:
            self.arduino =  Serial(port='/dev/ttyUSB0', baudrate=9600, timeout=.1)
        except Exception as e:
            print(e)

        th = Thread(self.centralwidget)
        th.changePixmap.connect(lambda image: self.setImage(image))
        th.changeName.connect(lambda name: self.setName(name))
        th.changeMnv.connect(lambda mnv: self.setMnv(mnv))
        th.changeTime.connect(lambda time: self.setTime(time))
        th.changePhoto.connect(lambda photo: self.setPhoto(photo))
        th.changeTemperature.connect(lambda temp: self.setTemperature(temp))
        th.start()

    @pyqtSlot(QImage, name='video')
    def setImage(self, image):
        image = QPixmap.fromImage(image)
        image = image.scaled(640, 480, Qt.KeepAspectRatio)
        self.video.setPixmap(image)

    @pyqtSlot(QImage, name='avatar')
    def setPhoto(self, photo):
        photo = QPixmap.fromImage(photo)
        self.photo.setStyleSheet("background-color: none")        
        self.photo.setPixmap(photo)


    @pyqtSlot(QImage, name='avatar7')
    def setPhoto7(self, qr_yte):
        qr_yte = QPixmap.fromImage(qr_yte)
        self.qr_yte.setPixmap(qr_yte)


    @pyqtSlot(str, name='time')
    def setTime(self, time):
        self.time_log.setStyleSheet("background-color: none;  border: 1px solid none;")
        self.time_log.setText('Time: ' + time)

    @pyqtSlot(str, name='temperature')
    def setTemperature(self, temperature):
        if temperature != "None":
            if (float(temperature) >= 37.5):
                self.temp.setStyleSheet("background-color: red;  border: 1px solid black;") 
                self.temp.setText('Temperature: > ' + temperature + '°C')
            else:
                self.temp.setStyleSheet("background-color: none;  border: 1px solid none;")
                self.temp.setText('Temperature: ' + temperature + '°C')
        else:
            self.temp.setStyleSheet("background-color: red;  border: 1px solid black;") 
            self.temp.setText('Temperature: ' + temperature)


    @pyqtSlot(str, name='mnv')
    def setMnv(self, name):
        self.mnv.setText('N.o Code: ' + name)


    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1080, 1920)
        MainWindow.setMinimumSize(QtCore.QSize(1080, 1920))
        MainWindow.setMaximumSize(QtCore.QSize(1080, 1920))
        MainWindow.setSizeIncrement(QtCore.QSize(1080, 1920))
        MainWindow.setBaseSize(QtCore.QSize(1080, 1920))
        font = QtGui.QFont('Arial', 10)
        font.setPointSize(8)
        MainWindow.setFont(font)
        self.centralwidget.setObjectName("centralwidget")
        self.video.setGeometry(QtCore.QRect(770, 620, 300, 300))
        self.video.setMinimumSize(QtCore.QSize(300, 300))
        self.video.setMaximumSize(QtCore.QSize(300, 300))
        self.video.setText("")
        self.video.setScaledContents(True)

        self.photo_title.setGeometry(QtCore.QRect(200, 10, 720, 100))
        self.photo_title.setText("")
        self.photo_title.setPixmap(QtGui.QPixmap("Image/NFQ7.png"))
        self.photo_title.setScaledContents(True)

        self.logo.setGeometry(QtCore.QRect(20, 1000, 1040, 720))         # cũ (20, 1080, 1040, 720))
        self.logo.setText("")
        self.logo.setPixmap(QtGui.QPixmap("Image/logo_nfq.jpg"))
        self.logo.setScaledContents(True)
        self.logo.setObjectName("logo")

        self.photo.setGeometry(QtCore.QRect(830, 180, 191, 201))
        self.photo.setText("")
        self.photo.setPixmap(QtGui.QPixmap("Image/circled_user_male_480px.png"))
        self.photo.setScaledContents(True)

        self.titkul_hotline.setGeometry(QtCore.QRect(0, 1782, 1080, 100))
        self.titkul_hotline.setText("")
        self.titkul_hotline.setPixmap(QtGui.QPixmap("Image/titkul_hotline.png"))
        self.titkul_hotline.setScaledContents(True)
        self.titkul_hotline.setObjectName("titkul_hotline")


        self.qr_yte.setGeometry(QtCore.QRect(220, 400, 400, 400))
        self.qr_yte.setPixmap(QtGui.QPixmap("Image/QRNFQ.jpg"))
        self.qr_yte.setText("")
        self.qr_yte.setObjectName("qr_yte")
        self.qr_yte.setScaledContents(True)

        self.mnv.setGeometry(QtCore.QRect(770, 570, 241, 31))
        font = QtGui.QFont('Arial', 12)
        font.setItalic(True)
        self.mnv.setFont(font)

        self.time_log.setGeometry(QtCore.QRect(790, 420, 260, 30))
        font = QtGui.QFont('Arial', 20)
        self.time_log.setFont(font)

        self.temp.setGeometry(QtCore.QRect(790, 460, 300, 30))
        font = QtGui.QFont('Arial', 20)
        self.temp.setFont(font)

        self.address.setGeometry(QtCore.QRect(100, 110, 1000, 50))
        self.address.setWordWrap(True)
        font_address = QtGui.QFont('Arial', 20)
        font_address.setItalic(True)
        self.address.setFont(font_address)

        self.three_step.setGeometry(QtCore.QRect(220, 270, 1000, 120))
        self.three_step.setWordWrap(True)
        font_three_step = QtGui.QFont('Arial', 14)
        font_three_step.setItalic(True)
        self.three_step.setFont(font_three_step)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1080, 19))

        MainWindow.setMenuBar(self.menubar)

        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def video_run(self):
        pass

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.time_log.setText(_translate("MainWindow", "Time:"))
        self.temp.setText(_translate("MainWindow", "Temperature:"))
        self.address.setText(_translate("MainWindow", "Address: {}".format(address_congty)))
        self.three_step.setText(_translate("MainWindow", "{}".format(three_step_nfq)))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
